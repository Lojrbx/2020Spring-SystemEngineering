X_data=load('X.mat');
X = X_data.X;
Y_data=load('Y.mat');
Y = Y_data.Y;
linear_regression(Y,X,0.05);