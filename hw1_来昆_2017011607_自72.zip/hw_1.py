import numpy as np
import matplotlib.pyplot as plt
from scipy import io
import os


# load .mat file
def load_mat():
    mat = io.loadmat('data.mat')
    data = mat['data']
    return data

# plot picture
def plot_data(q):
    plt.plot(q)
    plt.title('Traffic Flow - Time')
    plt.grid()
    plt.xlabel('time')
    plt.ylabel('Num of Vehicles/h')
    plt.show()

# Simple Moving Average
def MA(list_input,N):
    # -----INPUT------
    # list_input:输入的待平滑的list
    # N：滑动窗口长度
    # -----OUTPUT-----
    # list_output：输出的平滑后的list
    list_output = []
    for i in range(N-1, len(list_input)):
        list_slice = list_input[i-(N-1):i+1]
        list_output.append(np.mean(list_slice))
    return list_output

# Exponential Smooth
def ES(list_input,a):
    # -----INPUT------
    # list_input:输入的原始list;
    # a：平滑常数,[0,1];
    # -----OUTPUT-----
    # list_output:平滑后的list.
    list_output = []
    list_output.append(list_input[0])
    for i in range(1,len(list_input)):
        S_i = a*list_input[i-1] + (1-a)*list_output[i-1]
        list_output.append(S_i)
    return list_output





if __name__ == '__main__':
    flowdata = load_mat()
    #plot_data(flowdata)

    # MA
    MA_5 = MA(flowdata,5) # N = 5
    MA_30 = MA(flowdata,30) # N = 30

    # ES
    ES_02 = ES(flowdata,0.2)
    ES_005= ES(flowdata,0.05)

    # 画图
    plt.figure()
    plt.plot(flowdata)
    plt.title('Original')
    plt.grid()
    plt.xlabel('time')
    plt.ylabel('Num of Vehicles/h')

    plt.figure()
    plt.plot(MA_5)
    plt.title('MA,N=5')
    plt.grid()
    plt.xlabel('time')
    plt.ylabel('Num of Vehicles/h')

    plt.figure()
    plt.plot(MA_30)
    plt.title('MA, N=30')
    plt.grid()
    plt.xlabel('time')
    plt.ylabel('Num of Vehicles/h')

    plt.figure()
    plt.plot(ES_02)
    plt.title('Exponential Smooth, a=0.2')
    plt.grid()
    plt.xlabel('time')
    plt.ylabel('Num of Vehicles/h')

    plt.figure()
    plt.plot(ES_005)
    plt.title('Exponential Smooth, a=0.05')
    plt.grid()
    plt.xlabel('time')
    plt.ylabel('Num of Vehicles/h')

    plt.show()
    

