Data = load('data.mat');
data = Data.data;
linear_regression1(data,0.05);